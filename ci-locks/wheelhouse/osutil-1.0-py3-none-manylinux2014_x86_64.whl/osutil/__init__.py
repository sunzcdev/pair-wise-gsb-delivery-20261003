VALUE = "osutil 1.0 - linux build"
