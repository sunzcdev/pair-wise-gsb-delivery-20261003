VALUE = "hostwin 1.0 - native windows cp312 build"
