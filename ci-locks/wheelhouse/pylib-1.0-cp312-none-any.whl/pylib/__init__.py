VALUE = "pylib 1.0 - cp312 wheel"
