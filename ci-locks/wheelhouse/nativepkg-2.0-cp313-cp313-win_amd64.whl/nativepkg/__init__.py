VALUE = "nativepkg 2.0 - windows amd64 cp313 build"
