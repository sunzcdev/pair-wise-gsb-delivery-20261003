VALUE = "nativepkg 2.0 - linux x86_64 cp312 build"
