VALUE = "sharedlib 1.4.0 - universal"
