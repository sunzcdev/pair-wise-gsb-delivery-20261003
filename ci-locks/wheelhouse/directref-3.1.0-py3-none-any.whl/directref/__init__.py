VALUE = "directref 3.1.0 - direct file reference"
