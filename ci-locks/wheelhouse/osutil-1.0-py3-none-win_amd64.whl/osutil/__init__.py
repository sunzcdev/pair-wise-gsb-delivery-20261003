VALUE = "osutil 1.0 - windows build"
